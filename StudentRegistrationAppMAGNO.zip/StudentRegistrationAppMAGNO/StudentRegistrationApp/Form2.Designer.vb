﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        txtName = New TextBox()
        txtAge = New TextBox()
        Label3 = New Label()
        txtEmail = New TextBox()
        Label4 = New Label()
        btnText = New Button()
        Label5 = New Label()
        Label6 = New Label()
        cmbGender = New ComboBox()
        cmbCourse = New ComboBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.White
        Label1.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.MediumPurple
        Label1.Location = New Point(389, 166)
        Label1.Name = "Label1"
        Label1.Size = New Size(178, 35)
        Label1.TabIndex = 0
        Label1.Text = "Student Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.MediumPurple
        Label2.Location = New Point(389, 227)
        Label2.Name = "Label2"
        Label2.Size = New Size(58, 35)
        Label2.TabIndex = 1
        Label2.Text = "Age"
        ' 
        ' txtName
        ' 
        txtName.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtName.ForeColor = Color.MediumPurple
        txtName.Location = New Point(581, 163)
        txtName.Name = "txtName"
        txtName.Size = New Size(279, 42)
        txtName.TabIndex = 2
        ' 
        ' txtAge
        ' 
        txtAge.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtAge.ForeColor = Color.MediumPurple
        txtAge.Location = New Point(581, 227)
        txtAge.Name = "txtAge"
        txtAge.Size = New Size(279, 42)
        txtAge.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.White
        Label3.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.MediumPurple
        Label3.Location = New Point(389, 291)
        Label3.Name = "Label3"
        Label3.Size = New Size(76, 35)
        Label3.TabIndex = 5
        Label3.Text = "Email"
        ' 
        ' txtEmail
        ' 
        txtEmail.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtEmail.ForeColor = Color.MediumPurple
        txtEmail.Location = New Point(581, 291)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(279, 42)
        txtEmail.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.White
        Label4.Font = New Font("Calibri", 48F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.MediumPurple
        Label4.Location = New Point(459, 26)
        Label4.Name = "Label4"
        Label4.Size = New Size(372, 117)
        Label4.TabIndex = 8
        Label4.Text = "Register"
        ' 
        ' btnText
        ' 
        btnText.BackColor = Color.FromArgb(CByte(192), CByte(192), CByte(255))
        btnText.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnText.ForeColor = Color.MediumPurple
        btnText.Location = New Point(480, 485)
        btnText.Name = "btnText"
        btnText.Size = New Size(331, 62)
        btnText.TabIndex = 12
        btnText.Text = "Register"
        btnText.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.White
        Label5.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.MediumPurple
        Label5.Location = New Point(389, 360)
        Label5.Name = "Label5"
        Label5.Size = New Size(101, 35)
        Label5.TabIndex = 13
        Label5.Text = "Gender"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.White
        Label6.Font = New Font("Calibri", 14F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.MediumPurple
        Label6.Location = New Point(389, 415)
        Label6.Name = "Label6"
        Label6.Size = New Size(95, 35)
        Label6.TabIndex = 14
        Label6.Text = "Course"
        ' 
        ' cmbGender
        ' 
        cmbGender.BackColor = SystemColors.HighlightText
        cmbGender.ForeColor = Color.MediumPurple
        cmbGender.FormattingEnabled = True
        cmbGender.Items.AddRange(New Object() {"""Male""", """Female""", """Other"""})
        cmbGender.Location = New Point(581, 364)
        cmbGender.Name = "cmbGender"
        cmbGender.Size = New Size(279, 33)
        cmbGender.TabIndex = 16
        ' 
        ' cmbCourse
        ' 
        cmbCourse.ForeColor = Color.MediumPurple
        cmbCourse.FormattingEnabled = True
        cmbCourse.Items.AddRange(New Object() {"""Mathematics""", """Science""", """History"""})
        cmbCourse.Location = New Point(581, 419)
        cmbCourse.Name = "cmbCourse"
        cmbCourse.Size = New Size(279, 33)
        cmbCourse.TabIndex = 17
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1102, 630)
        Controls.Add(cmbCourse)
        Controls.Add(cmbGender)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(btnText)
        Controls.Add(Label4)
        Controls.Add(txtEmail)
        Controls.Add(Label3)
        Controls.Add(txtAge)
        Controls.Add(txtName)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form2"
        Text = "RegistrationForm2.vb"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtAge As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnText As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbGender As ComboBox
    Friend WithEvents cmbCourse As ComboBox
End Class
